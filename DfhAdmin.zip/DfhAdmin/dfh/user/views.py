import re
import hashlib

from django.shortcuts import render, redirect
from django.views.generic import View
from django.http import HttpResponse
from django import forms
from django.http import JsonResponse
from django.forms import ValidationError

from dfh.user.models import User
# Create your views here.

# 定义MD5加密函数
def md5(pwd):
    m = hashlib.md5('dfh123'.encode('utf8'))
    m.update(pwd.encode('utf8'))
    return m.hexdigest()

class UserModelForm(forms.ModelForm):
    """用户form组件类"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for filed in self.fields.values():
            filed.widget.attrs.update({'class': 'layui-input'})

    # 元类
    class Meta:
        model = User
        fields = '__all__'
        exclude = ['ip_path', 'last_login', 'role']
        # 定义字段名
        labels = {
            'username': '用户名',
            'password': '密码',
            'email': '邮箱',
            'telphone': '电话号码'
        }
        # 自定义属性
        widgets = {
            'password': forms.widgets.PasswordInput,
        }
        # 定义错误信息
        error_messages = {
            'username': {
                'required': '不能为空',
                'unique': '当前用户名已经存在'
            },
            'password': {
                'required': '不能为空'
            }
        }

    # 自定义验证邮箱钩子
    def clean_email(self):
        email_value = self.cleaned_data.get('email')
        if email_value:
            ret = re.search(
                r'\w[-\w.+]*@([A-Za-z0-9][-A-Za-z0-9]+\.)+[A-Za-z]{2,14}',
                email_value)
            if ret is None:
                raise ValidationError('邮箱格式错误')
        return email_value

    # 自定义验证手机号码钩子
    def clean_telphone(self):
        telphone_value = self.cleaned_data.get('telphone')
        if telphone_value:
            ret = re.search(r'(13|14|15|17|18|19)[0-9]{9}', telphone_value)
            if ret is None:
                raise ValidationError('电话号码格式错误')
        return telphone_value


class Login(View):
    """登入"""
    def get(self, request):

        return render(request, 'login.html')


class Index(View):
    """首页"""
    def get(self, request):

        return render(request, 'index.html')


class Admin_list(View):
    """用户列表"""
    def get(self, request):
        # 获取搜索关键词
        username = request.GET.get('username')
        
        if username:
            # 查询包含关键词的数据
            user_obj = User.objects.filter(username__contains=username).all()
        else:
            # 查询所有用户数据
            user_obj = User.objects.all()
        return render(request, 'admin-list.html', locals())


class Admin_list_add(View):
    """用户添加"""

    def get(self, request):
        user_form = UserModelForm()

        return render(request, 'admin-add.html', locals())

    def post(self, request):
        # 实例化Modelform组件类
        user_form = UserModelForm(request.POST)

        # 校验数据
        if user_form.is_valid():
            # 校验通过
            # 获取真实IP地址
            if 'HTTP_X_FORWARDED_FOR' in request.META:
                ip_path = request.META['HTTP_X_FORWARDED_FOR']
            else:
                ip_path = request.META['REMOTE_ADDR']

            # 把IP地址插入数据字典
            user_form.cleaned_data['ip_path'] = ip_path
            # 把密码用MD5函数加密一遍
            user_form.cleaned_data['password'] = md5(user_form.cleaned_data['password'])

            # 数据库添加
            User.objects.create(**user_form.cleaned_data)

            # 校验数据通过后，返回前台的标签，控制JS跳转
            flag = True
            return render(request, 'admin-add.html', locals())
        else:
            # 校验不通过，返回当前页面
            return render(request, 'admin-add.html', locals())

class Admin_list_edit(View):
    """用户更新"""
    def get(self, request, cid):
        # 查询要编辑的数据
        customer = User.objects.filter(pk=cid).first()
        user_form = UserModelForm(instance=customer)
        
        return render(request, 'admin-edit.html', locals())

    def post(self,request,cid):
        customer = User.objects.filter(pk=cid).first()
        # 实例化Modelform组件类
        user_form = UserModelForm(request.POST,instance=customer)

        # 校验数据
        if user_form.is_valid():
            # 校验通过
            # 获取真实IP地址
            if 'HTTP_X_FORWARDED_FOR' in request.META:
                ip_path = request.META['HTTP_X_FORWARDED_FOR']
            else:
                ip_path = request.META['REMOTE_ADDR']

            # 把IP地址插入数据字典
            user_form.cleaned_data['ip_path'] = ip_path
            # 把密码用MD5函数加密一遍
            user_form.cleaned_data['password'] = md5(user_form.cleaned_data['password'])

            # 数据库添加
            User.objects.filter(pk=customer.pk).update(**user_form.cleaned_data)

            # 校验数据通过后，返回前台的标签，控制JS跳转
            flag = True
            return render(request, 'admin-add.html', locals())
        else:
            # 校验不通过，返回当前页面
            return render(request, 'admin-add.html', locals())

class Admin_list_del(View):
    """用户删除"""
    def get(self,request,cid):
        # 删除对应的数据
        User.objects.filter(pk=cid).delete()
        return render(request, 'admin-list.html', locals())