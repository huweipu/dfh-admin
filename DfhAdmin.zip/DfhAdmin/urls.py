"""DfhAdmin URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, re_path, include
from dfh.user.views import (Login, Index, Admin_list, Admin_list_add,
                            Admin_list_edit, Admin_list_del, Admin_list_status,
                            Loginout)

urlpatterns = [
    path('admin/', admin.site.urls),
    re_path('^$', Index.as_view(), name='index'),  # 首页
    re_path('^index/$', Index.as_view(), name='index'),  # 首页
    re_path('^login/$', Login.as_view(), name='login'),  # 登入
    re_path('^loginout/$', Loginout.as_view(), name='loginout'),  # 登出
    re_path('^index/admin-list/$', Admin_list.as_view(),
            name='admin_list'),  # 用户列表
    re_path('^index/admin-list/add/$',
            Admin_list_add.as_view(),
            name='user_add'),  # 用户添加
    re_path('^index/admin-list/edit/(\d+)/$',
            Admin_list_edit.as_view(),
            name='user_edit'),  # 用户更新
    re_path('^index/admin-list/del/(\d+)/$',
            Admin_list_del.as_view(),
            name='user_del'),  # 用户删除
    re_path('^index/admin-list/status/(?P<id>\d+)/$',
            Admin_list_status.as_view(),
            name='user_status'),  # 用户状态管理
]
