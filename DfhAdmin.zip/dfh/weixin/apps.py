from django.apps import AppConfig


class WeixinConfig(AppConfig):
    name = 'weixin'
