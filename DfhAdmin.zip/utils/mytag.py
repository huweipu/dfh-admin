from django import template

register = template.Library()

@register.inclusion_tag('moduel/menu_base.html')
def menu(request):
    a = 1
    return {'menu':a}