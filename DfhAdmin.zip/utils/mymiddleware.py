from django.urls import reverse
from django.utils.deprecation import MiddlewareMixin
from django.shortcuts import redirect
from dfh.user import models
# from django.conf import settings

# 自定义中间件(访问每个方法都验证登入状态)
class UserAuth(MiddlewareMixin):
    """"自定义验证登入状态中间件"""
    def process_request(self,request):
        # 放行的url
        green_light = [reverse('login'),]
        # print(request.path_info,request.path)
        # 验证访问的url是否是放行的url
        if request.path in green_light:
            return

        # 获取登入存在session中的id值
        user_id = request.session.get('user_id')
        
        # 验证id是否存在
        if user_id:

            # 查询ID对应的用户信息
            user_obj = models.User.objects.get(pk=user_id)

            # 把用户信息追加给request对象
            request.user_obj = user_obj
            return
        else:
            # 验证不通过重定向登入页面
            return redirect('login')
